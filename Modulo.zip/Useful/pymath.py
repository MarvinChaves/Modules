import math

class PyMath:
    def __init__(self):
        pass

    def add(n1=0, n2=0):
        'returns x + y'
        return n1 + n2 
    
    def subtract(n1=0, n2=0):
        'returns x - y'
        return n1 - n2
    
    def multiply(n1=0, n2=0):
        'returns x * y'
        return n1 * n2
    
    def division(n1=0, n2=0):
        'returns x / y'
        return n1 / n2
    
    def sqrt(num=0):
        'returns the square root of x'
        return math.sqrt(num)
    
    def power(num, po):
        'returns the power of x'
        return num ** po
        
