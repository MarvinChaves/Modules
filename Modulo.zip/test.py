from Useful.itelligence import *
from Useful.pymath import *
from Useful.file import *
import os

Itelligence.comparing()